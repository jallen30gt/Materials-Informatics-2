%Made by J.T.B. Overvelde on 9 may 2011

global np numModes maxIncr maxNumIncr wMin
global GridSpaceX GridSpaceY numHolesX numHolesY imperf sizeMesh
global saveData phi MatDir AbDir saveFile
global MatSaveDir saveFig saveMov Mat xv yv muVar K rho mo